﻿using ComunicacionVistaControlador.Models;
using Microsoft.AspNetCore.Mvc;

namespace ComunicacionVistaControlador.Controllers
{
    public class ProductosController : Controller
    {
        public IActionResult Detalle(int id)
        {
            // Lógica para obtener el producto de la base de datos
            var producto = new ProductoDetalleViewModel
            {
                Id = id,
                Nombre = "Laptop X1",
                Precio = 1250.99M,
                EnStock = true
            };

            // Pasa el objeto View Model a la vista
            return View(producto);
        }

        public IActionResult Index()
        {
            ViewData["Mensaje"] = "Bienvenido a la Tienda";
            ViewData["TotalProductos"] = 45;
            return View();
        }
        public IActionResult AcercaDe()
        {
            ViewBag.Titulo = "Sobre Nosotros";
            ViewBag.AnioFundacion = 2010;
            return View();
        }

        public IActionResult CrearProducto(ProductoDetalleViewModel nuevoProducto)
        {
            // Lógica para guardar el producto
            TempData["Resultado"] = $"Producto '{nuevoProducto.Nombre}' creado con éxito.";

            // Redirige a otra acción
            return RedirectToAction("Listado");
        }
        public IActionResult Listado()
        {
            // TempData persiste de la acción CrearProducto a Listado
            return View();
        }

    }

}
